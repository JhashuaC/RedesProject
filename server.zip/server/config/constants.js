module.exports = {
    PREFIJO_LOCAL: 77,
    KEY_EMISOR: "JMJ77",
    API_KEY_URL: 'https://192.168.0.10:3001/get_api_key/'
};