// index.js
const express = require('express');
const fs = require('fs');
const https = require('https');
const cors = require('cors');
const loginRoutes = require('./controllers/loginController');
const enviarRoutes = require('./controllers/enviarSinpeController');
const recibirRoutes = require('./controllers/recibirSinpeController');
const db = require('./config/db'); // importa el pool

const app = express();
app.use(cors());
app.use(express.json());

app.use('/api', loginRoutes);
app.use('/api', enviarRoutes);
app.use('/api', recibirRoutes);

const sslOptions = {
    key: fs.readFileSync('./certs/key.pem'),
    cert: fs.readFileSync('./certs/cert.pem')
};


db.getConnection()
    .then(conn => {
        console.log('✅ Conexión a la base de datos exitosa');
        conn.release(); // liberar la conexión
    })
    .catch(err => {
        console.error('❌ Error al conectar con la base de datos:', err.message);
    });



https.createServer(sslOptions, app).listen(5000, () => {
    console.log('Servidor HTTPS corriendo en puerto 5000');
});